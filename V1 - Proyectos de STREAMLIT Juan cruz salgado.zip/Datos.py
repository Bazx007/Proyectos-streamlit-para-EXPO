import streamlit as st
from datasets import TODOS, configurar

configurar("📊")

st.title("📊 Expo de Datos de Argentina")
st.caption("Facultad de Informática · Una app por dataset, explicada de forma simple")

st.write(
    "En esta página reunimos los trabajos de todos. Usá el menú de la izquierda para "
    "elegir un dataset: cada página explica **de qué trata** y muestra, en su propia celda, "
    "**las aplicaciones** que hizo cada compañero."
)

# Tarjetas: 2 por fila para que se lean bien
for i in range(0, len(TODOS), 2):
    cols = st.columns(2)
    for col, d in zip(cols, TODOS[i:i + 2]):
        with col:
            st.markdown(
                f"<div class='tarjeta'><h3>{d['emoji']} {d['nombre']}</h3>"
                f"<p>{d['resumen']}</p>"
                f"<small>{len(d['apps'])} app(s)</small></div>",
                unsafe_allow_html=True,
            )
